# Startup script for entire system.

Write-Host "=" * 60 -ForegroundColor Cyan
Write-Host "AUTOMATED NEGOTIATION SYSTEM" -ForegroundColor Yellow  
Write-Host "=" * 60 -ForegroundColor Cyan
Write-Host ""

# Check environment
if (!(Test-Path "system_manager.py")) {
    Write-Host "ERROR: Run this script from the Project directory" -ForegroundColor Red
    Read-Host "Press Enter to exit" ; exit 1
}

$venvPython = "..\venv\Scripts\python.exe"
if (!(Test-Path $venvPython)) {
    Write-Host "ERROR: Virtual environment Python not found at $venvPython" -ForegroundColor Red
    Read-Host "Press Enter to exit" ; exit 1
}

# User interface to choose negotiation mode. There are three choices: full system manager, human vs AI, quick bilateral.
Write-Host "CHOOSE YOUR INTERFACE:" -ForegroundColor Yellow
Write-Host ""
Write-Host "  [1] Full System Manager" -ForegroundColor Green
Write-Host "      Complete CLI with all options" -ForegroundColor Gray
Write-Host ""
Write-Host "  [2] Human vs AI Negotiation" -ForegroundColor Green  
Write-Host "      Practice negotiating with agents" -ForegroundColor Gray
Write-Host ""
Write-Host "  [3] Quick Bilateral Setup" -ForegroundColor Green
Write-Host "      Fast agent vs agent setup" -ForegroundColor Gray
Write-Host ""
Write-Host "  [Q] Quit" -ForegroundColor Red
Write-Host ""

$choice = Read-Host "Select option [1/2/3/Q]"

try { # Option handling for mode selected by user.
    # Check if virtual environment is already active, otherwise activate it
    if (-not $env:VIRTUAL_ENV) {
        Write-Host "Activating virtual environment..." -ForegroundColor Green
        & "..\venv\Scripts\Activate.ps1"
        if ($LASTEXITCODE -ne 0) {
            Write-Host "ERROR: Failed to activate virtual environment" -ForegroundColor Red
            Read-Host "Press Enter to exit" ; exit 1
        }
    } else {
        Write-Host "Using active virtual environment: $env:VIRTUAL_ENV" -ForegroundColor Green
    }

    switch ($choice.ToUpper()) {
        "1" { 
            Write-Host "Launching Full System Manager..." -ForegroundColor Green
            & $venvPython system_manager.py 
        }
        "2" { 
            Write-Host "Launching Human-Agent Negotiation..." -ForegroundColor Green
            & $venvPython human_negotiator.py 
        }
        "3" { 
            Write-Host "Quick Bilateral Setup:" -ForegroundColor Green
            Write-Host "A=Aggressive, C=Cooperative, G=Gradual"
            $agents = Read-Host "Enter two agents (e.g., AC, AG, CG, AA)"
            if ($agents.Length -eq 2) {
                & $venvPython -c "
from system_manager import SystemManager
sm = SystemManager()
agents = ['$($agents[0])', '$($agents[1])']
sm.launch_bilateral_negotiation(agents)
"
            } else {
                Write-Host "Invalid input. Use two letters (A/C/G)" -ForegroundColor Red
            }
        }
        "Q" { 
            Write-Host "Goodbye!" -ForegroundColor Yellow 
            exit 0 
        }
        default { 
            Write-Host "Invalid choice" -ForegroundColor Red 
        }
    }
    
} catch {
    Write-Host "ERROR: $_" -ForegroundColor Red
} finally {
    Read-Host "`nPress Enter to close"
}
